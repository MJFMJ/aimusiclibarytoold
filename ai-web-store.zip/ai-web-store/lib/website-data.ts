export const websiteData = [
  {
    id: '1',
    name: 'ChatGPT',
    description: 'AI-powered chatbot for natural language conversations',
    imageUrl: '/placeholder.svg?height=400&width=600',
    url: 'https://chat.openai.com',
    category: 'Chatbot'
  },
  {
    id: '2',
    name: 'DALL-E',
    description: 'AI system that creates images from textual descriptions',
    imageUrl: '/placeholder.svg?height=400&width=600',
    url: 'https://openai.com/dall-e-2',
    category: 'Image Generation'
  },
  {
    id: '3',
    name: 'Midjourney',
    description: 'AI-powered tool for creating artwork and illustrations',
    imageUrl: '/placeholder.svg?height=400&width=600',
    url: 'https://www.midjourney.com',
    category: 'Image Generation'
  },
  {
    id: '4',
    name: 'Udio',
    description: 'AI Song Creator that helps creating Songs',
    imageUrl: 'https://deltl.de/wp-content/uploads/2024/04/Udio.png',
    url: 'https://www.udio.com/home',
    category: 'AI Song Generation'
  },
  {
    id: '5',
    name: 'Lobe',
    description: 'Easy-to-use tool for training machine learning models',
    imageUrl: '/placeholder.svg?height=400&width=600',
    url: 'https://www.lobe.ai',
    category: 'Machine Learning'
  },
  {
    id: '6',
    name: 'Runway',
    description: 'AI-powered creative tools for video editing and generation',
    imageUrl: '/placeholder.svg?height=400&width=600',
    url: 'https://runwayml.com',
    category: 'Video'
  }
]

