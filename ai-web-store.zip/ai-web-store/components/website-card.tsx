import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { WebsiteModal } from './website-modal'
import Image from 'next/image'

interface Website {
  id: string
  name: string
  description: string
  imageUrl: string
  url: string
  category: string
}

export function WebsiteCard({ website }: { website: Website }) {
  return (
    <WebsiteModal website={website}>
      <Card className="flex flex-col h-full cursor-pointer transition-all hover:shadow-lg">
        <CardHeader>
          <div className="relative w-full h-48 mb-4">
            <Image
              src={website.imageUrl || '/placeholder.svg?height=400&width=600'}
              alt={website.name}
              fill
              className="object-cover rounded-md"
            />
          </div>
          <CardTitle>{website.name}</CardTitle>
        </CardHeader>
        <CardContent className="flex-grow">
          <Badge variant="secondary">{website.category}</Badge>
        </CardContent>
      </Card>
    </WebsiteModal>
  )
}

