'use client'

import { Button } from "@/components/ui/button"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { ExternalLink } from 'lucide-react'
import Image from 'next/image'

interface Website {
  id: string
  name: string
  description: string
  imageUrl: string
  url: string
  category: string
}

export function WebsiteModal({ website, children }: { website: Website; children: React.ReactNode }) {
  return (
    <Dialog>
      <DialogTrigger asChild>
        {children}
      </DialogTrigger>
      <DialogContent className="sm:max-w-[425px]">
        <DialogHeader>
          <DialogTitle>{website.name}</DialogTitle>
          <DialogDescription>{website.category}</DialogDescription>
        </DialogHeader>
        <div className="relative w-full h-48 mb-4">
          <Image
            src={website.imageUrl || '/placeholder.svg?height=400&width=600'}
            alt={website.name}
            fill
            className="object-cover rounded-md"
          />
        </div>
        <p className="text-sm text-muted-foreground">{website.description}</p>
        <Button asChild className="w-full mt-4">
          <a href={website.url} target="_blank" rel="noopener noreferrer">
            Visit Website <ExternalLink className="ml-2 h-4 w-4" />
          </a>
        </Button>
      </DialogContent>
    </Dialog>
  )
}

